﻿CREATE SCHEMA [config]
    AUTHORIZATION [dbo];

