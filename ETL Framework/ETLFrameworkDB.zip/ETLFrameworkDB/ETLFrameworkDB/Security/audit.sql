﻿CREATE SCHEMA [audit]
    AUTHORIZATION [dbo];

