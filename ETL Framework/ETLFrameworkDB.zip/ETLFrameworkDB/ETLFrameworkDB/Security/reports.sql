﻿CREATE SCHEMA [reports]
    AUTHORIZATION [dbo];

