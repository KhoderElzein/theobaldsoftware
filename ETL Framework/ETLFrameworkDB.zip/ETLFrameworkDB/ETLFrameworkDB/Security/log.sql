﻿CREATE SCHEMA [log]
    AUTHORIZATION [dbo];

